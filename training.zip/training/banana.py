import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import os

# Dataset path
dataset_dir = 'D:/Banana_plant/training/Banana_data/diseases/Leaves'

# Step 1: Load Pre-Trained Model (Feature Extractor)
base_model = tf.keras.applications.EfficientNetB0(
    weights='imagenet', 
    include_top=False, 
    input_shape=(128, 128, 3)
)

# Step 2: Add Custom Layers for Classification
x = base_model.output
x = GlobalAveragePooling2D()(x)  # Global average pooling to reduce dimensions
x = Dense(256, activation='relu')(x)  # Fully connected layer
num_classes = len(os.listdir(dataset_dir))  # Automatically infer classes from dataset
predictions = Dense(num_classes, activation='softmax')(x)  # Output layer

# Final Model
model = Model(inputs=base_model.input, outputs=predictions)

# Step 3: Freeze Base Model Layers (for Feature Extraction)
for layer in base_model.layers:
    layer.trainable = False

# Step 4: Compile the Model
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

# Step 5: Data Preparation (Using Data Augmentation)
train_datagen = ImageDataGenerator(
    rescale=1.0 / 255, 
    rotation_range=20, 
    width_shift_range=0.2, 
    height_shift_range=0.2, 
    horizontal_flip=True, 
    validation_split=0.2  # 20% for validation
)

train_generator = train_datagen.flow_from_directory(
    dataset_dir,
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical',
    subset='training'  # Training data
)

validation_generator = train_datagen.flow_from_directory(
    dataset_dir,
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical',
    subset='validation'  # Validation data
)

# Step 6: Callbacks (Early Stopping and Model Checkpoint)
callbacks = [
    EarlyStopping(
        monitor='val_loss', 
        patience=5, 
        restore_best_weights=True
    ),
    ModelCheckpoint(
        filepath="D:/Banana_plant/models/best_Leaves_detection_model.keras",  # Save as .keras format
        monitor='val_loss', 
        save_best_only=True
    )
]

# Step 7: Train the Model
history = model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=20,  # Start with 20 epochs
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    validation_steps=validation_generator.samples // validation_generator.batch_size,
    callbacks=callbacks
)

# Step 8: Fine-Tuning (Optional for Better Performance)
# Unfreeze the deeper layers of the base model
for layer in base_model.layers[-30:]:  # Unfreeze last 30 layers
    layer.trainable = True

# Re-compile the model with a lower learning rate for fine-tuning
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5), 
    loss='categorical_crossentropy', 
    metrics=['accuracy']
)

# Fine-tune the model
fine_tune_history = model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=10,  # Additional 10 epochs for fine-tuning
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    validation_steps=validation_generator.samples // validation_generator.batch_size,
    callbacks=callbacks
)

# Step 9: Save the Final Model in .keras format
model.save("D:/Banana_plant/models/final_Leaves_detection_model.keras")  # Save the final model in .keras format
