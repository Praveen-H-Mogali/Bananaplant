import os
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint

# Define constants
IMG_SIZE = (128, 128)
BATCH_SIZE = 32
EPOCHS = 10

# Paths
TRAIN_DIR = 'D:/Banana_plant/training/Banana_data'
MODEL_SAVE_DIR = 'D:/Banana_plant/models'
PARTS_DIR = os.path.join(TRAIN_DIR, 'parts')
DISEASE_DIR = os.path.join(TRAIN_DIR, 'diseases')

# Ensure model save directory exists
if not os.path.exists(MODEL_SAVE_DIR):
    os.makedirs(MODEL_SAVE_DIR)

# Image Data Generators
train_datagen = ImageDataGenerator(rescale=1./255)
part_train_generator = train_datagen.flow_from_directory(
    PARTS_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

# Generators for disease detection
disease_train_generators = {}
for part in ['Fruits', 'Leaves', 'Stem']:
    part_disease_dir = os.path.join(DISEASE_DIR, part)
    if not os.path.exists(part_disease_dir):
        raise FileNotFoundError(f"Directory not found: {part_disease_dir}")
    disease_train_generators[part] = train_datagen.flow_from_directory(
        part_disease_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='categorical'
    )

# Model creation function
def create_cnn_model(num_classes):
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(IMG_SIZE[0], IMG_SIZE[1], 3)),
        MaxPooling2D(pool_size=(2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# Function to train and save models
def train_and_save_model(model, save_path, train_gen):
    try:
        # Remove save_best_only=True for debugging
        checkpoint = ModelCheckpoint(save_path, save_best_only=False)
        model.fit(train_gen, epochs=EPOCHS, callbacks=[checkpoint])
        # Explicit save at the end of training
        model.save(save_path)  # Explicitly save model after training
        print(f"Model saved successfully at: {save_path}")
    except Exception as e:
        print(f"Error while saving model: {e}")
        raise

# Train and save part detection model
print("Training Part Detection Model...")
part_detection_model = create_cnn_model(num_classes=3)
part_model_path = os.path.join(MODEL_SAVE_DIR, 'final_part_detection_model.keras').replace("\\", "/")
train_and_save_model(part_detection_model, part_model_path, part_train_generator)

# Train and save disease detection models for Fruits, Leaves, and Stem
disease_class_counts = {
    "Fruits": 5,
    "Leaves": 8,
    "Stem": 4
}

for part, num_classes in disease_class_counts.items():
    print(f"Training {part} Disease Detection Model...")
    disease_model = create_cnn_model(num_classes)
    disease_model_path = os.path.join(MODEL_SAVE_DIR, f'final_{part}_detection_model.keras').replace("\\", "/")
    train_and_save_model(disease_model, disease_model_path, disease_train_generators[part])

print("All models trained and saved successfully!")
