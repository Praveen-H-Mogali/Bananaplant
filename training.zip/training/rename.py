import os
from PIL import Image

# Paths
source_folder = "D:/Banana_plant/training/Banana_plants/Stem/Panama disease_augmented_images"  # Folder containing original images
renamed_folder = "D:/Banana_plant/training/Banana_data/Stem/Panama disease"  # Folder to save renamed images

# Create the output folder if it doesn't exist
os.makedirs(renamed_folder, exist_ok=True)

# Start renaming and saving images
print("Starting renaming process...")
counter = 1  # Counter to ensure unique names
for file_name in os.listdir(source_folder):
    file_path = os.path.join(source_folder, file_name)

    # Check for valid image file extensions
    if file_name.lower().endswith(('png', 'jpg', 'jpeg')) and os.path.isfile(file_path):
        # Open the image and convert to RGB to ensure uniformity
        img = Image.open(file_path).convert('RGB')

        # Create a new unique name
        new_file_name = f"banana_{counter}.jpeg"

        # Save the image to the renamed folder
        img.save(os.path.join(renamed_folder, new_file_name), format='JPEG')
        counter += 1  # Increment the counter

print(f"Renaming completed. Renamed images saved to: {renamed_folder}")
