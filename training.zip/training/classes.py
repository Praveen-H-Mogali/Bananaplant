import os
import json

def get_classes_hierarchy(dataset_path):
    """
    Recursively generates a class hierarchy in the desired JSON-like format.
    Args:
        dataset_path (str): Path to the dataset.
    Returns:
        list: Nested hierarchy of classes and sub-classes.
    """
    hierarchy = []
    items = os.listdir(dataset_path)
    folders = [item for item in items if os.path.isdir(os.path.join(dataset_path, item))]

    for folder in folders:
        sub_path = os.path.join(dataset_path, folder)
        sub_classes = get_classes_hierarchy(sub_path)

        if sub_classes:
            hierarchy.append({folder: sub_classes})
        else:
            hierarchy.append(folder)

    return hierarchy

# Path to your dataset folder
dataset_path = "D:/Banana_plant/training/Banana_data"

# Generate the class hierarchy
classes_hierarchy = get_classes_hierarchy(dataset_path)

# Print in JSON-like format
print(json.dumps(classes_hierarchy, indent=4))
