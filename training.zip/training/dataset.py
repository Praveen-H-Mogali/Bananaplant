import os
from PIL import Image
import albumentations as A
import numpy as np

# Paths
source_folder = "D:/Banana_plant/training/Banana_plants/Stem/Panama disease"  # Original images folder
resized_folder = "D:/Banana_plant/training/Banana_plants/Stem/Panama disease_resized_images"  # Resized images folder
augmented_folder = "D:/Banana_plant/training/Banana_plants/Stem/Panama disease_augmented_images"  # Augmented images folder

# Image resize dimensions
resize_dim = (128, 128)

# Create folders if they don't exist
os.makedirs(resized_folder, exist_ok=True)
os.makedirs(augmented_folder, exist_ok=True)

### Step 1: Resize Images and Save as JPEG ###
print("Starting image resizing...")
for file_name in os.listdir(source_folder):
    file_path = os.path.join(source_folder, file_name)
    if file_name.lower().endswith(('png', 'jpg', 'jpeg')) and os.path.isfile(file_path):
        # Open and resize image
        img = Image.open(file_path).convert('RGB')
        resized_img = img.resize(resize_dim)

        # Save resized image as JPEG
        base_name, _ = os.path.splitext(file_name)  # Extract base name without extension
        resized_img.save(os.path.join(resized_folder, f"{base_name}.jpeg"), format='JPEG')

print("Image resizing completed. Resized images saved to:", resized_folder)

### Step 2: Apply Albumentations on Resized Images ###
print("Starting Albumentations augmentation...")

# Define Albumentations transformation pipeline
transform = A.Compose([
    A.HorizontalFlip(p=0.5),
    A.RandomBrightnessContrast(p=0.2),
    A.Rotate(limit=40, p=0.5),
    A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.05, rotate_limit=30, p=0.5),
])

# Apply augmentations to resized images
for file_name in os.listdir(resized_folder):
    file_path = os.path.join(resized_folder, file_name)
    if file_name.lower().endswith(('jpeg')) and os.path.isfile(file_path):
        # Open and convert resized image to numpy array
        img = Image.open(file_path)
        img_np = np.array(img)

        # Apply augmentation
        base_name, _ = os.path.splitext(file_name)  # Extract original file name without extension
        for i in range(7):  # Generate 7 augmented images per resized image
            augmented = transform(image=img_np)['image']
            augmented_img = Image.fromarray(augmented)

            # Save augmented images as JPEG
            new_file_name = f"{base_name}_aug_{i + 1}.jpeg"
            augmented_img.save(os.path.join(augmented_folder, new_file_name), format='JPEG')

print("Albumentations augmentation completed. Augmented images saved to:", augmented_folder)
