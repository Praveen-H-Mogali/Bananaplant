from tensorflow.keras.models import load_model
import numpy as np
from tensorflow.keras.preprocessing.image import load_img, img_to_array

# Load pre-trained models
part_detection_model = load_model("D:/Banana_plant/models/final_part_detection_model.keras")
disease_models = {
    "Fruits": load_model("D:/Banana_plant/models/final_fruits_detection_model.keras"),
    "Leaves": load_model("D:/Banana_plant/models/final_Leaves_detection_model.keras"),
    "Stem": load_model("D:/Banana_plant/models/final_Stem_detection_model.keras"),
}

# Define disease classes for each part of the plant
disease_classes = {
    "Fruits": ["Anthracnose", "Banana Streak Virus", "Cigar End Rot", "Healthy Fruit", "Moko Disease Fruit"],  # Add disease classes for Fruits
    "Leaves": ["Banana Black Sigatoka Disease", "Banana Bract Mosaic Virus Disease","Banana Bunchy Top Virus","Banana Insect Pest Disease","Banana Moko Disease","Banana Panama Disease","Banana Yellow Sigatoka Disease","Healthy Leaf"],  # Example for Leaves (adjust based on your dataset)
    "Stem": ["Bacterial Soft Rot", "Banana Xanthomonas","Healthy stem","Panama disease"]    # Example for Root (adjust based on your dataset)
}

# Preprocess input image
def preprocess_image(image_path, target_size=(128, 128)):
    img = load_img(image_path, target_size=target_size)
    img_array = img_to_array(img) / 255.0
    return np.expand_dims(img_array, axis=0)

# Prediction pipeline
def predict_pipeline(image_path):
    # Step 1: Detect the plant part
    img = preprocess_image(image_path)
    part_prediction = part_detection_model.predict(img)
    part_class = ["Fruits", "Leaves", "Stem", "Root"][np.argmax(part_prediction)]
    print(f"Detected Part: {part_class}")

    # Step 2: Detect disease for the identified part
    disease_model = disease_models[part_class]
    disease_prediction = disease_model.predict(img)
    disease_class = disease_classes[part_class][np.argmax(disease_prediction)]
    print(f"Detected Disease: {disease_class}")

# Test the pipeline
predict_pipeline("D:/Banana_plant/training/Banana_data/diseases/Leaves/Healthy Leaf/Healthy Leaf (1).jpeg")
